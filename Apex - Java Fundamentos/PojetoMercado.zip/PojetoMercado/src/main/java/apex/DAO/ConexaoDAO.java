package apex.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ConexaoDAO {
    Connection conn;
    
    public ConexaoDAO(){
        try {//tente
            String textoConexao = "jdbc:mysql://localhost:3306/mercado?user=root&password=";
            conn = DriverManager.getConnection(textoConexao);
        } catch (SQLException ex) {//pega
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }
    
}
